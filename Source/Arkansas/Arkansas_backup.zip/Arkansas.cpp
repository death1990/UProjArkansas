// Copyright Epic Games, Inc. All Rights Reserved.

#include "Arkansas.h"
#include "Modules/ModuleManager.h"

IMPLEMENT_PRIMARY_GAME_MODULE( FDefaultGameModuleImpl, Arkansas, "Arkansas" );
