#include "GTChildMeshData.h"

FGTChildMeshData::FGTChildMeshData() {
    this->SkinnedAsset = NULL;
}

